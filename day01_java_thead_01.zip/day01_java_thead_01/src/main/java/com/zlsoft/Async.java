package com.zlsoft;

import lombok.extern.slf4j.Slf4j;

import java.io.FileReader;

@Slf4j(topic = "c.Async")
public class Async {
    public static void main(String[] args) {
        String s = Integer.toBinaryString(15);
        System.out.println(s);

//        new Thread(() -> System.out.println("hello.")).start();
//        log.debug("do others things...");
    }
}
