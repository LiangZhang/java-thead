package com.zlsoft.threadPoolExecutor.forkjoinPool;

import lombok.extern.slf4j.Slf4j;

/**
 * @version 1.0.0
 * @RESTful：Create-post Read-get update-put/path delete-delete
 * @package: com.zlsoft.threadPoolExecutor.forkjoinPool
 * @ClassName: ForkJoinPoolTest.java
 * @author: L.Z QQ.191288065@qq.com
 * @Description
 * @createTime 2020年09月15日 08:25:00
 */
@Slf4j(topic = "zl.ForkJoinPoolTest")
public class ForkJoinPoolTest {
}
    
    
    