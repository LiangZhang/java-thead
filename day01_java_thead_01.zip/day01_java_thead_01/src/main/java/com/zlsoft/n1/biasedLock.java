package com.zlsoft.n1;

/**
 * @version 1.0.0
 * @RESTful：Create-post Read-get update-put/path delete-delete
 * @package: com.zlsoft.n1
 * @ClassName: biasedLock.java
 * @author: L.Z QQ.191288065@qq.com
 * @Description 广力年报-年报基层框架API
 * @createTime 2020年07月01日 09:04:00
 */

/**
 * 偏向锁：-BiasedLock：-　markword对象后三位101
 */
public class biasedLock {
    public static void main(String[] args) {

    }
}