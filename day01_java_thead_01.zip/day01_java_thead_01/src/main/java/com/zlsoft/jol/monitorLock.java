package com.zlsoft.jol;

/**
 * @version 1.0.0
 * @RESTful：Create-post Read-get update-put/path delete-delete
 * @package: com.zlsoft.jol
 * @ClassName: monitorLock.java
 * @author: L.Z QQ.191288065@qq.com
 * @Description 广力年报-年报基层框架API
 * @createTime 2020年07月01日 09:21:00
 */
public class monitorLock {
}