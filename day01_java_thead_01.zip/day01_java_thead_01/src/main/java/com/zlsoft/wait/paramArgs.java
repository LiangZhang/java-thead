package com.zlsoft.wait;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @version 1.0.0
 * @RESTful：Create-post Read-get update-put/path delete-delete
 * @package: com.zlsoft.wait
 * @ClassName: paramArgs.java
 * @author: L.Z QQ.191288065@qq.com
 * @Description
 * @createTime 2020年07月27日 17:40:00
 */
public class paramArgs {
    public static void main(String[] args) {
         test1(1,2,"4");
    }

    public static void test1(Object... args) {
        Object[] a = args;
        test2(a);
    }
    public static void test2(Object... args) {
        System.out.println(args);
    }
}
    
    
    