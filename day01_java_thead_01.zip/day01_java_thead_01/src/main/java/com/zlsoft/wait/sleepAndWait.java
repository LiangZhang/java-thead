package com.zlsoft.wait;

import lombok.extern.slf4j.Slf4j;

import static com.zlsoft.core.Sleeper.sleep;


/**
 * @version 1.0.0
 * @RESTful：Create-post Read-get update-put/path delete-delete
 * @package: com.zlsoft.wait
 * @ClassName: sleepAndWait.java
 * @author: L.Z QQ.191288065@qq.com
 * @Description 广力年报-年报基层框架API
 * @createTime 2020年07月10日 11:40:00
 */
@Slf4j(topic = "c.")
public class sleepAndWait {
    static final Object room = new Object();
    static boolean hasCigarette = false;
    static boolean hasTakeout = false;

    public static void main(String[] args) {





    }
}