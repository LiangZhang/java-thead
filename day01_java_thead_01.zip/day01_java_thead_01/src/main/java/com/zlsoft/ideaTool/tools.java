package com.zlsoft.ideaTool;

/**
 * @version 1.0.0
 * @RESTful：Create-post Read-get update-put/path delete-delete
 * @package: com.zlsoft.ideaTool
 * @ClassName: tools.java
 * @author: L.Z QQ.191288065@qq.com
 * @Description
 * @createTime 2020年09月07日 17:07:00
 */
public class tools {

}
    
    
    